import cv2
import numpy as np
import matplotlib.pyplot as plt

image_path1 = r'C:\Users\akter\OneDrive\Documents\Uni\Year 3\Comp338\A1\victoria1.jpg'
image_path2 = r'C:\Users\akter\OneDrive\Documents\Uni\Year 3\Comp338\A1\victoria2.jpg'

img1 = cv2.imread(image_path1, cv2.IMREAD_GRAYSCALE)
img2 = cv2.imread(image_path2, cv2.IMREAD_GRAYSCALE)

sift_detector = cv2.SIFT_create()
orb_detector = cv2.ORB_create()

# Detect keypoints and compute descriptors 
keypoints1_sift, descriptors1_sift = sift_detector.detectAndCompute(img1, None)
keypoints2_sift, descriptors2_sift = sift_detector.detectAndCompute(img2, None)
keypoints1_orb, descriptors1_orb = orb_detector.detectAndCompute(img1, None)
keypoints2_orb, descriptors2_orb = orb_detector.detectAndCompute(img2, None)

#Brute-Force Matcher
bf_matcher = cv2.BFMatcher()

# Match descriptors
matches_sift = bf_matcher.knnMatch(descriptors1_sift, descriptors2_sift, k=2)
matches_orb = bf_matcher.knnMatch(descriptors1_orb, descriptors2_orb, k=2)

# Apply ratio test 
good_matches_sift = []
for match1, match2 in matches_sift:
    if match1.distance < 0.75 * match2.distance:
        good_matches_sift.append(match1)

good_matches_orb = []
for match1, match2 in matches_orb:
    if match1.distance < 0.75 * match2.distance:
        good_matches_orb.append(match1)

img_matches_sift = cv2.drawMatches(img1, keypoints1_sift, img2, keypoints2_sift, good_matches_sift, None, flags=cv2.DrawMatchesFlags_NOT_DRAW_SINGLE_POINTS)
img_matches_orb = cv2.drawMatches(img1, keypoints1_orb, img2, keypoints2_orb, good_matches_orb, None, flags=cv2.DrawMatchesFlags_NOT_DRAW_SINGLE_POINTS)

# Display the results
plt.figure(figsize=(12, 6))

plt.subplot(1, 2, 1)
plt.imshow(img_matches_sift)
plt.title('SIFT Matches')

plt.subplot(1, 2, 2)
plt.imshow(img_matches_orb)
plt.title('ORB Matches')

plt.show()


