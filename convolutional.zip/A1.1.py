import numpy as np
import cv2
import matplotlib.pyplot as plt

def Convolution(input_matrix, kernel_matrix):
    input_height, input_width = input_matrix.shape
    kernel_height, kernel_width = kernel_matrix.shape
    # Get the dimensions of the input matrix and the kernel
    pad_height = kernel_height // 2
    pad_width = kernel_width // 2
    # Calculate the padding 
    padded_input = np.pad(input_matrix, ((pad_height, pad_height), (pad_width, pad_width),), mode='constant') # Pad the input matrix with zeros 
    result = np.zeros_like(input_matrix, dtype=np.float32) # Create a result matrix of the same size as the input_matrix 
    for i in range(input_height):
        for j in range(input_width): # Loop through each pixel 
            region = padded_input[i:i + kernel_height, j:j + kernel_width]# Extract a region 
            result[i, j] = np.sum(region * kernel_matrix)# Perform the convolution operation 
    return result
# End of function

input_matrix = np.array([[3, 6, 9],[12, 15, 18],[21, 24, 27]], dtype=np.float32) # Create a 3x3 sample input matrix 
custom_kernel = np.array([[2, -2],[1, -1]], dtype=np.float32) # Create a 2x2 sample kernel 
convolution_result = Convolution(input_matrix, custom_kernel) # Perform the convolution  and store the result 

plt.subplot(1, 2, 1)
plt.imshow(input_matrix, cmap='gray')
plt.title('Original Input Matrix') #original input matrix 

plt.subplot(1, 2, 2)
plt.imshow(convolution_result, cmap='gray')
plt.title('Convolution Result') #convolution result 

plt.show() # Display two subplots 
