import cv2
import numpy as np
import matplotlib.pyplot as plt

image_path1 = r'C:\Users\akter\OneDrive\Documents\Uni\Year 3\Comp338\A1\victoria1.jpg'
image_path2 = r'C:\Users\akter\OneDrive\Documents\Uni\Year 3\Comp338\A1\victoria2.jpg'

img1 = cv2.imread(image_path1, cv2.IMREAD_GRAYSCALE)
img2 = cv2.imread(image_path2, cv2.IMREAD_GRAYSCALE)

orb = cv2.ORB_create()

keypoints1, descriptors1 = orb.detectAndCompute(img1, None)
keypoints2, descriptors2 = orb.detectAndCompute(img2, None)

# s keypoints 
image1_with_keypoints = cv2.drawKeypoints(img1, keypoints1, None, color=(0, 255, 0), flags=0)
image2_with_keypoints = cv2.drawKeypoints(img2, keypoints2, None, color=(0, 255, 0), flags=0)

# Display the images 
plt.figure(figsize=(12, 6))
plt.subplot(1, 2, 1)
plt.imshow(image1_with_keypoints, cmap='gray')
plt.title('Image 1 with ORB Keypoints')

plt.subplot(1, 2, 2)
plt.imshow(image2_with_keypoints, cmap='gray')
plt.title('Image 2 with ORB Keypoints')

plt.show()
